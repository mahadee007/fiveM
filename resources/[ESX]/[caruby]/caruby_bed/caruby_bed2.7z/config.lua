Config              = {}
Config.MaxDistance = 1.5

Config.BedList = {

	{
		text = '[E] Lie on the bed',
		heading = -20.0,
		objCoords  = {x = 356.73, y = -585.71, z = 43.11},---pillbox bed
	},

	{
		text = '[E] Lie on the bed',
		heading = -20.0,
		objCoords  = {x = 360.51, y = -586.66, z = 43.11},--pillbox bed
	},

	{
		text = '[E] Lie on the bed',
		heading = -20.0,
		objCoords  = {x = 353.12, y = -584.66, z = 43.50},---pillbox bed
	},

	{
		text = '[E] Lie on the bed',
		heading = -20.0,
		objCoords  = {x = 349.62, y = -583.53, z = 43.022},---pillbox bed
	},

	{
		text = '[E] Lie on the bed',
		heading = 80.0,
		objCoords  = {x = 344.80, y = -581.12, z = 43.02},---pillbox bed
	},

	{
		text = '[E] Lie on the bed',
		heading = 80.0,
		objCoords  = {x = 334.09, y = -578.43, z = 43.01}, --pillbox bed
	},

	{
		text = '[E] Lie on the bed',
		heading = -20.0,
		objCoords  = {x = 323.64, y = -575.16, z = 43.02}, --pillbox bed
	},

	{
		text = '[E] Lie on the bed',
		heading = -20.0,
		objCoords  = {x = 326.97, y = -576.229, z = 43.02}, --pillbox bed
	},

	{
		text = '[E] Lie on the bed',
		heading = 160.0,
		objCoords  = {x = 354.24, y = -592.74, z = 43.11}, --pillbox bed
	},

	{
		text = '[E] Lie on the bed',
		heading = 160.0,
		objCoords  = {x = 357.34, y = -594.45, z = 43.11}, --pillbox bed
	},

	{
		text = '[E] Lie on the bed',
		heading = 160.0,
		objCoords  = {x = 350.80, y = -591.72, z = 43.11}, --pillbox bed 
	},

	{
		text = '[E] Lie on the bed',
		heading = 160.0,
		objCoords  = {x = 346.89, y = -591.01, z = 42.58},   --pillbox bed 
	}
}